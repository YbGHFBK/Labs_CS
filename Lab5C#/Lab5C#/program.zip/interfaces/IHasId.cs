﻿public interface IHasId
{
    public int Id { get; set; }

}