﻿public enum UserRole
{
    Regular,
    Admin
}