﻿public enum TrainType
{
    Cargo,
    Passenger
}

public enum TrainCondition
{
    Running,
    OnMaintenance,
    AtTheDepot
}